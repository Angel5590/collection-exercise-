import UIKit

var myCollection = ("Ilike to collect")

myCollection.append("picture frame")
myCollection.append("manga")
myCollection += ["pens"]

myCollection.sort()

print(myCollection)
